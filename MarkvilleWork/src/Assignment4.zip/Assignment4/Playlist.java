package Assignment4;
import java.util.*;
import java.io.*;

public class Playlist {
	private String playlistName;
	private int songNum;
	private ArrayList<Song> songs = new ArrayList<Song>();
	public Playlist(String playlistName,int numSongs, ArrayList<Song>songs) {
		this.playlistName = playlistName;
		this.songNum = numSongs;
		this.songs = songs;
	}
	
	public String getPlaylistName() {
		return this.playlistName;
	}
	public String toString() {
		String returnString = String.format("Playlist Name: %s%nNumber of songs: %d%nSong details:%n",playlistName,songNum);
		for (int i = 1; i <= songNum; i++) {
			returnString += i+". "+songs.get(i-1).toString();
		}
		return returnString;
	}
}
