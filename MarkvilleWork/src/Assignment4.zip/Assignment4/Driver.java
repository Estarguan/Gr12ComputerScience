package Assignment4;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class Driver implements ActionListener {
    // To Do:
    // - I might hard code the locations of the stuff in input field to make it centered
    static ArrayList<Song> songs = new ArrayList<Song>();
    static ArrayList<Playlist> playlists = new ArrayList<Playlist>();
    static JTextField inputField = new JTextField();
    static JButton submitButton = new JButton("Submit");
    static int option = 0;

    static JPanel panel = new JPanel();
    static JPanel menuPanel = new JPanel();
    static JPanel inputPanel = new JPanel();
    static JPanel displayPanel = new JPanel();
    static JScrollPane scrollPanel = new JScrollPane(displayPanel);

    public Driver() {
        // Setting up frames and panels
        JFrame frame = new JFrame("Playlist Manager Frame");
        frame.setPreferredSize(new Dimension(1200, 800));
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        menuPanel.setLayout(new GridLayout(8, 1, 0, 0));

        // Making the menu panel options
        subMenuOne(menuPanel);

        // Making the input panel options
        inputField.setPreferredSize(new Dimension(300, inputField.getPreferredSize().height));
        inputField.setVisible(false); // Initially set inputField to be invisible
        inputPanel.add(inputField);

        submitButton.setVisible(false);
        submitButton.addActionListener(this);
        submitButton.setActionCommand("submit");
        inputPanel.add(submitButton);

        // Adding a border around my panels
        panel.setBorder(new LineBorder(Color.black, 1));
        menuPanel.setBorder(new LineBorder(Color.black, 1));
        inputPanel.setBorder(new LineBorder(Color.black, 1));
        displayPanel.setBorder(new LineBorder(Color.black, 1));

        panel.add(menuPanel);
        panel.add(inputPanel);
        panel.add(scrollPanel);

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("opt1")) {
            displayAllLists();
        } else if (command.equals("opt2")) {
            displayOneList();
        } else if (command.equals("opt3")) {
            option = 3;
            inputField.setVisible(true); // Make the inputField visible
            inputField.setText(""); // Clear any previous input
            submitButton.setVisible(true);
            inputPanel.revalidate(); // Revalidate the input panel to apply changes
            inputPanel.repaint(); // Repaint the input panel to show updates
        } else if (command.equals("submit")) {
            if (option == 3) {
                try {
                    addList(inputField.getText());
                    inputField.setVisible(false); // Optionally hide it again after submission
                    submitButton.setVisible(false);
                    inputField.setText(""); // Clear input after submission
                    inputPanel.revalidate(); // Revalidate to apply changes
                    inputPanel.repaint(); // Repaint to show updates
                } catch (IOException error) {
                    JOptionPane.showMessageDialog(null, "You somehow got an IOException IDK how you did that",
                            "File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    public void displayAllLists() {
        displayPanel.removeAll();
        displayPanel.setLayout(new BoxLayout(displayPanel, BoxLayout.Y_AXIS));
        String[] titles = new String[playlists.size()];
        for (int i = 0; i < playlists.size(); i++) {
            titles[i] = playlists.get(i).getPlaylistName();
        }
        JList<String> list = new JList<String>(titles);
        displayPanel.add(list);

        // Wrap displayPanel in a scroll pane and update panel layout
        scrollPanel = new JScrollPane(displayPanel); // Update scrollPanel

        // Remove the old scroll panel if present and add the updated scrollPanel
        panel.removeAll(); // Clear everything from panel to prevent duplications
        panel.add(menuPanel); // Re-add menu panel
        panel.add(inputPanel);
        panel.add(scrollPanel); // Add the updated display panel in a scroll pane

        // Refresh panel to apply updates
        panel.revalidate();
        panel.repaint();
    }

    public void displayOneList() {
        // Clear existing content in displayPanel
        displayPanel.removeAll();
        displayPanel.setLayout(new BoxLayout(displayPanel, BoxLayout.Y_AXIS));

        // Add updated playlist details directly to displayPanel
        for (Playlist playlist : playlists) {
            JTextArea textArea = new JTextArea(playlist.toString());
            textArea.setEditable(false);
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            displayPanel.add(textArea);
            displayPanel.add(Box.createVerticalStrut(10)); // Add spacing between playlists
        }

        // Wrap displayPanel in a scroll pane and update panel layout
        scrollPanel = new JScrollPane(displayPanel); // Update scrollPanel

        // Remove the old scroll panel if present and add the updated scrollPanel
        panel.removeAll(); // Clear everything from panel to prevent duplications
        panel.add(menuPanel); // Re-add menu panel
        panel.add(inputPanel);
        panel.add(scrollPanel); // Add the updated display panel in a scroll pane

        // Refresh panel to apply updates
        panel.revalidate();
        panel.repaint();
    }

    public void addList(String fileName) throws IOException {
        boolean gettingFile = true;
        BufferedReader inFile = null;
        do {
            try {
                inFile = new BufferedReader(new FileReader(fileName));
                gettingFile = false;
            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(null, "File Does Not Exist",
                        "File Error", JOptionPane.ERROR_MESSAGE);
                return; // Exit if file doesn't exist
            }
        } while (gettingFile);
        String title = inFile.readLine();
        int songNum = Integer.parseInt(inFile.readLine());
        for (int i = 0; i < songNum; i++) {
            String songTitle = inFile.readLine();
            String artist = inFile.readLine();
            String genre = inFile.readLine();
            double rating = Double.parseDouble(inFile.readLine());
            Time songTime = new Time(inFile.readLine());
            songs.add(new Song(songTitle, artist, genre, rating, songTime));
        }

        playlists.add(new Playlist(title, songNum, songs));
        System.out.println(playlists);
        inFile.close();
    }

    public void subMenuOne(JPanel menuPanel) {
        JButton opt1 = new JButton("Display a list of all your playlists");
        opt1.addActionListener(this);
        opt1.setActionCommand("opt1");
        JButton opt2 = new JButton("Display information of a particular playlist");
        opt2.addActionListener(this);
        opt2.setActionCommand("opt2");
        JButton opt3 = new JButton("Add a new playlist");
        opt3.addActionListener(this);
        opt3.setActionCommand("opt3");
        JButton opt4 = new JButton("Remove a playlist");
        opt4.addActionListener(this);
        opt4.setActionCommand("opt4");
        JButton opt5 = new JButton("Copy playlist");
        opt5.addActionListener(this);
        opt5.setActionCommand("opt5");
        JButton opt6 = new JButton("Sub playlist");
        opt6.addActionListener(this);
        opt6.setActionCommand("opt6");
        JButton opt7 = new JButton("Common Songs");
        opt7.addActionListener(this);
        opt7.setActionCommand("opt7");
        JButton opt8 = new JButton("Return to main menu");
        opt8.addActionListener(this);
        opt8.setActionCommand("opt8");
        menuPanel.add(opt1);
        menuPanel.add(opt2);
        menuPanel.add(opt3);
        menuPanel.add(opt4);
        menuPanel.add(opt5);
        menuPanel.add(opt6);
        menuPanel.add(opt7);
        menuPanel.add(opt8);
    }

    public static void main(String[] args) throws IOException {
        new Driver();
    }
}
