package Assignment4;

public class Time {
	private int hours;
	private int minutes;
	private int seconds;
	
	public Time(String time) {
		int colonCount = 0;
		for (int i =0; i < time.length();i++) {
			if (time.charAt(i) == ':') {
				colonCount++;
			}
		}
		//3:03:35
		if (colonCount == 1) {
			this.hours = 0;
			this.minutes = Integer.parseInt(time.substring(0,time.indexOf(':')));
			this.seconds = Integer.parseInt(time.substring(time.indexOf(':')+1));
		}else if (colonCount == 2) {
			this.hours = Integer.parseInt(time.substring(0,time.indexOf(':')));
			this.minutes = Integer.parseInt(time.substring(time.indexOf(':'),time.lastIndexOf(':')));
			this.seconds = Integer.parseInt(time.substring(time.lastIndexOf(':')+1));
		}
	}
	
	public int getMinutes() {
		return this.minutes;
	}
	public int getHours() {
		return this.hours;
	}
}
